import React from 'react';
import { useState } from 'react';

export default function ProductPlus() {
  const [subtotal, setSubtotal] = useState(0);

  function addSubtotalUpdate(price) {
    setSubtotal(subtotal + price);
  }

  function subtractSubtotalUpdate(price, validity) {
    if (validity) {
      //Checks to make sure that the minus button is pressed with more than 0 concurrent items in cart
      setSubtotal(subtotal - price);
    }
  }

  return (
    <div id="bodyAndSubtotal">
      <div id="body">
        <Product
          img="https://store.colorfulpalette.jp/cdn/shop/products/cap_220209_02_sp_1800x1800.jpg?v=1644345299"
          imgalt="Black baseball cap with pink text reading Shooting Star embroidered on the front"
          name="Shooting Star Baseball Cap"
          price={30}
          parentEventHandler1={addSubtotalUpdate}
          parentEventHandler2={subtractSubtotalUpdate}
        />
        <Product
          img="https://store.colorfulpalette.jp/cdn/shop/products/rakko_web_photo01-L_1800x1800.jpg?v=1642578149"
          imgalt="Sky blue t-shirt with a cartoon sea otter design"
          name="Sea Otter T-Shirt (L)"
          price={25}
          parentEventHandler1={addSubtotalUpdate}
          parentEventHandler2={subtractSubtotalUpdate}
        />
        <Product
          img="https://store.colorfulpalette.jp/cdn/shop/products/usagi_02_img_1800x1800.jpg?v=1672940707"
          imgalt="A purple bunny doll with pink ribbons on its right ear and neck"
          name="Purple Bunny Doll"
          price={15}
          parentEventHandler1={addSubtotalUpdate}
          parentEventHandler2={subtractSubtotalUpdate}
        />
        <Product
          img="https://store.colorfulpalette.jp/cdn/shop/products/1C_01-front-L_1800x1800.jpg?v=1668493249"
          imgalt="Black t-shirt with a skeleton design and purple splatter marks"
          name="Skeleton T-Shirt (L)"
          price={20}
          parentEventHandler1={addSubtotalUpdate}
          parentEventHandler2={subtractSubtotalUpdate}
        />
      </div>
      <div id="subtotalArea">
        <h6>Subtotal: ${subtotal}</h6>
      </div>
    </div>
  );
}

function Product(props) {
  const [counter, setCounter] = useState(0);
  var validityCheck = false; //Used to prevent subtotal from going below 0; basically tells above code to not subtract

  function counterSubtract() {
    if (counter > 0) {
      setCounter(counter - 1);
      validityCheck = true;
    }
  }

  function counterAdd() {
    setCounter(counter + 1);
  }

  return (
    <div className="product">
      <div className="productNameDiv">
        <h2 className="productName">{props.name}</h2>
      </div>
      <img className="productImage" src={props.img} alt={props.imgalt} />
      <h3 className="productPrice">${props.price}</h3>
      <div className="productCounter">
        <button
          type="submit"
          className="minusButton"
          onClick={() => {
            counterSubtract();
            props.parentEventHandler2(props.price, validityCheck);
          }}
        >
          -
        </button>
        <p className="counter">{counter}</p>
        <button
          type="submit"
          className="addButton"
          onClick={() => {
            counterAdd();
            props.parentEventHandler1(props.price);
          }}
        >
          +
        </button>
      </div>
    </div>
  );
}
