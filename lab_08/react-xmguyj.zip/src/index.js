import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import ProductPlus from './Product.js';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div id="all">
      <div id="header">
        <h1>Shopping Cart</h1>
      </div>
      <ProductPlus />
      <div id="footer">
        <h4>Page by Terry Lee</h4>
      </div>
    </div>
  </React.StrictMode>
);
