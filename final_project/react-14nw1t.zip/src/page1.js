import React from 'react';

export default function Page1() {
  return (
    <div id="page1">
      <h2 className="page1_h2">What are Mobile Rhythm Games?</h2>
      <p className="page1_p">
        Rhythm games are a popular genre of video games, enjoyed by many around
        the world in various forms. Some know rhythm games for their arcade
        variations, like Dance Dance Revolution, while others know them for
        their console variations, like Guitar Hero. For anyone enthusiastic
        about music, rhythm games can provide lovely experiences, experiences of
        challenge or of relaxation, of intense dedication or of casual fun.
      </p>
      <p className="page1_p">
        Mobile rhythm games are available mainly on modern smart devices,
        primarily touch phones and tablets. Unlike the older rhythm games like
        Dance Dance Revolution or Guitar Hero, mobile rhythm games don’t require
        full-body movement or a large external device, only needing your device
        of choice and hand dexterity. Since the popularization of touch phones
        and tablets, mobile rhythm games have expanded rapidly as a genre, and
        now present a diverse market with many interested players.
      </p>
      <p className="page1_p">
        Because of their easy accessibility, varied forms of gameplay, and, in
        my opinion, exhilarating nature, I think everyone should give mobile
        rhythm games a try! This website aims to introduce you to the basic idea
        of mobile rhythm games, what you should look for in them, and what
        specific titles exist in the market. At the end of this page is also a
        rhythm game recommendation algorithm, which can help you find a mobile
        rhythm game perfectly matched to your tastes!
      </p>
      <h2 className="page1_h2">What do I need?</h2>
      <p className="page1_p">
        As mentioned, mobile rhythm games only really need a smart device, like
        a smartphone or a tablet. Rhythm games at their core aren’t too
        performance-intensive, but as the market has grown, more and more games
        have tried to spice up their presentation, whether it be through
        gameplay or visuals. This means that while most games will run fine on
        lower end phones or tablets, having a newer phone or tablet will allow
        you to run more games at their best performance. Regardless, all you
        really need is probably the phone you already have!
      </p>
      <p className="page1_p">
        Most rhythm games require you to only use two fingers; for smartphone
        users, this means you use your two thumbs, while for tablet users, you
        use your index fingers. As you play harder levels in mobile rhythm
        games, playing on a phone may become more limiting, while playing with a
        tablet may be far more liberating, allowing you to use more fingers and
        move your hands more easily. (As may be expected, most veterans use
        large tablets with high performance capabilities.) Many beginners worry
        about this issue, but if you’re just starting, no need to worry about
        having the best device! You can get far using just your thumbs on a
        phone, and have lots of fun doing it.
      </p>
      <p className="page1_p">
        With all that said, now that you’re ready, below are some specific
        titles you can check out to enter the diverse, exciting world of mobile
        rhythm games!
      </p>
    </div>
  );
}
