import React from 'react';

export default function GameCard(prop) {
  return (
    <div className="gamecard">
      <div className="gamecard_part1">
        <div className="gamecard_header">
          <h1 className="gamecard_title">{prop.title}</h1>
          <div className="gamecard_details">
            <p className="gamecard_rd">
              <strong>Released: </strong>
              {prop.rd}
            </p>
            <p className="gamecard_diff">
              <strong>Difficulty: </strong>
              {prop.diff}
            </p>
            <p className="gamecard_music">
              <strong>Music: </strong>
              {prop.music}
            </p>
          </div>
        </div>
        <div className="gamecard_top_right">
          <img className="gamecard_img" src={prop.src} alt={prop.alt} />
        </div>
      </div>
      <hr className="gamecard_hr" />
      <div className="gamecard_part2">
        <p className="gamecard_gameplay">
          <strong>Gameplay: </strong>
          {prop.gameplay}
        </p>
      </div>
      <hr className="gamecard_hr" />
      <div className="gamecard_part3">
        <p className="gamecard_strengths">
          <strong>Strengths: </strong>
        </p>
        <ul className="gamecard_strengths_ul">
          <li className="gamecard_strength1">{prop.strength1}</li>
          <li className="gamecard_strength2">{prop.strength2}</li>
          <li className="gamecard_strength3">{prop.strength3}</li>
        </ul>
      </div>
      <hr className="gamecard_hr" />
      <div className="gamecard_part4">
        <p className="gamecard_link">
          <strong>Relevant Link:</strong>
          <a href={prop.link} target="_blank">
            {' '}
            {prop.link_name}
          </a>
        </p>
      </div>
    </div>
  );
}
