import React from 'react';
import Page1 from './page1.js';
import Page2 from './page2.js';
import Page3 from './page3.js';

export default function Main() {
  function handleClickHeader1() {
    document.querySelector('#header').style.display = 'none';
    document.querySelector('#subheader1').style.display = 'block';
    document.querySelector('#page1').style.display = 'none';
    document.querySelector('#page2').style.display = 'block';
  }

  function handleClickHeader2() {
    document.querySelector('#header').style.display = 'none';
    document.querySelector('#subheader2').style.display = 'block';
    document.querySelector('#page1').style.display = 'none';
    document.querySelector('#page3').style.display = 'block';
  }

  function handleClickSubheader1() {
    document.querySelector('#subheader1').style.display = 'none';
    document.querySelector('#header').style.display = 'block';
    document.querySelector('#page2').style.display = 'none';
    document.querySelector('#page1').style.display = 'block';
  }

  function handleClickSubheader2() {
    document.querySelector('#subheader2').style.display = 'none';
    document.querySelector('#header').style.display = 'block';
    document.querySelector('#page3').style.display = 'none';
    document.querySelector('#page1').style.display = 'block';
  }

  return (
    <div id="all">
      <div id="header">
        <div id="header_flex">
          <h1 className="header_h1">The World of Mobile Rhythm Games</h1>
          <hr className="header_hr" />
          <div id="header_buttons">
            <div id="header_button_1" className="header_buttons_sub">
              <button
                type="submit"
                className="header_button"
                onClick={handleClickHeader1}
              >
                See List of Games
              </button>
            </div>
            <div id="header_verticalhr"></div>
            <div id="header_button_2" className="header_buttons_sub">
              <button
                type="submit"
                className="header_button"
                onClick={handleClickHeader2}
              >
                Get a Recommendation
              </button>
            </div>
          </div>
        </div>
        <hr className="header_border" />
      </div>

      <div id="subheader1">
        <div id="subheader1_flex">
          <div id="subheader1_return">
            <button
              type="submit"
              className="return_button"
              onClick={handleClickSubheader1}
            >
              Return to Home
            </button>
          </div>
          <div id="subheader1_title">
            <h1 className="header_h1">Mobile Rhythm Games: My Picks</h1>
          </div>
        </div>
        <hr className="header_border" />
      </div>

      <div id="subheader2">
        <div id="subheader2_flex">
          <div id="subheader2_return">
            <button
              type="submit"
              className="return_button"
              onClick={handleClickSubheader2}
            >
              Return to Home
            </button>
          </div>
          <div id="subheader2_title">
            <h1 className="header_h1">Rhythm Game Recommendation Algorithm</h1>
          </div>
        </div>
        <hr className="header_border" />
      </div>

      <div id="body">
        <Page1 />
        <Page2 />
        <Page3 />
      </div>

      <div id="footer">
        <hr id="footer_border" />
        <div id="footer_flex">
          <h5 id="footer_l">Website by Terry Lee</h5>
          <h5 id="footer_r">Last Updated: 12/7/2023</h5>
        </div>
      </div>
    </div>
  );
}
