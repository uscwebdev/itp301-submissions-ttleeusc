import React from 'react';
import GameCard from './gamecard.js';
import { useState } from 'react';

export default function Page3() {
  var a1 = true;
  var a2 = true;

  const [title, setTitle] = useState('');
  const [rd, setRd] = useState('');
  const [diff, setDiff] = useState('');
  const [music, setMusic] = useState('');
  const [src, setSrc] = useState('');
  const [alt, setAlt] = useState('');
  const [gameplay, setGameplay] = useState('');
  const [strength1, setStrength1] = useState('');
  const [strength2, setStrength2] = useState('');
  const [strength3, setStrength3] = useState('');
  const [linkname, setLinkname] = useState('');
  const [link, setLink] = useState('');

  function handleClickStart() {
    document.querySelector('#page3_initial').style.display = 'none';
    document.querySelector('#page3_q1').style.display = 'flex';
  }

  function handleClickQ1A1() {
    document.querySelector('#page3_q1').style.display = 'none';
    document.querySelector('#page3_q2').style.display = 'flex';
    a1 = true;
  }

  function handleClickQ1A2() {
    document.querySelector('#page3_q1').style.display = 'none';
    document.querySelector('#page3_q2').style.display = 'flex';
    a1 = false;
  }

  function handleClickQ2A1() {
    document.querySelector('#page3_q2').style.display = 'none';
    document.querySelector('#page3_q3').style.display = 'flex';
    a2 = true;
  }

  function handleClickQ2A2() {
    document.querySelector('#page3_q2').style.display = 'none';
    document.querySelector('#page3_q3').style.display = 'flex';
    a2 = false;
  }

  function handleClickQ3A1() {
    if (a1 == true && a2 == true) {
      setTitle('Muse Dash');
      setRd('June 2018');
      setDiff('Easy');
      setMusic('Electronic');
      setSrc(
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQqBKUxYz0qLMyHq7Hti3ol1-KnwzIXg7bHmg&usqp=CAU'
      );
      setAlt('Muse Dash app cover image');
      setGameplay(
        'Tap notes or dodge obstacles as they reach the goal point at the end of two horizontal lanes.'
      );
      setStrength1('Easy & fun to pick up and play any time');
      setStrength2(
        'Bright colors & pop aesthetic may be particularly appealing to some'
      );
      setStrength3('Frequent song updates');
      setLinkname('Nintendo Switch Version Trailer');
      setLink('https://youtu.be/1pt4kwFOpAg?si=g_nc21ChpOezURmM');
    } else if (a1 == true && a2 == false) {
      setTitle('Deemo II');
      setRd('January 2022');
      setDiff('Easy');
      setMusic('Classical (Piano)');
      setSrc(
        'https://play-lh.googleusercontent.com/H_zK8nYN2dEai8dh8Gd66eXMGkdOUOdp63Gxuldw9jlrg-tfYefHxDNBG9fjRkGxhA'
      );
      setAlt('Deemo II app cover image');
      setGameplay(
        'Conventional; tap notes as they fall on a still horizontal line. Notably sensitive to inputs. Rewards high precision.'
      );
      setStrength1('Easy to learn, hard to master');
      setStrength2('Composition-accurate piano sound effects add to immersion');
      setStrength3('Heavy focus on narrative & non-rhythm-game gameplay');
      setLinkname('Official Release Trailer');
      setLink('https://youtu.be/hJooJyL8hI8?si=QmLDaUGu2skA4x7X');
    } else if (a1 == false && a2 == true) {
      setTitle('Arcaea');
      setRd('March 2017');
      setDiff('Hard');
      setMusic('Electronic');
      setSrc(
        'https://img.utdstc.com/icon/5b7/89c/5b789cf76ea01189cb71d1d464810766b3c9d5f70f2ae3ee5239d4f804b9152b:200'
      );
      setAlt('Arcaea app cover image');
      setGameplay(
        'A revolutionary “3D” rhythm game: notes come down a single lane, but vary in both horizontal and vertical positions.'
      );
      setStrength1('Incredibly satisfying gameplay once basics are grasped');
      setStrength2(
        'Especially rewarding in the long term for those seeking a real challenge'
      );
      setStrength3('Simple, clean presentation in gameplay and UI');
      setLinkname('Official Trailer');
      setLink('https://youtu.be/ZcF9JQ44_sw?si=bbLYHt9kAoNHhLuQ');
    } else if (a1 == false && a2 == false) {
      setTitle('Cytus II');
      setRd('January 2018');
      setDiff('Medium');
      setMusic('Electronic');
      setSrc(
        'https://play-lh.googleusercontent.com/OWPLo_aeRocMDZH_V0VRa06XT642hwoUav3JjxXY3LCtb_qnWQuXjhZ1lKdT8Inz0yIL'
      );
      setAlt('Cytus II app cover image');
      setGameplay(
        'A horizontal line moves up and down the screen, and notes must be pressed as they contact the line.'
      );
      setStrength1(
        'One-of-a-kind gameplay requiring constant, flexible movement'
      );
      setStrength2('Well received story mode');
      setStrength3('Exceptional art direction across the board');
      setLinkname('Official Trailer');
      setLink('https://youtu.be/IAS52XC2pto?si=xB7fzchtjGidRaBy');
    }

    document.querySelector('#page3_q3').style.display = 'none';
    document.querySelector('#page3_results').style.display = 'flex';
  }

  function handleClickQ3A2() {
    if (a1 == true && a2 == true) {
      setTitle('VOEZ');
      setRd('May 2016');
      setDiff('Medium');
      setMusic('Variety');
      setSrc(
        'https://play-lh.googleusercontent.com/cS3tC7peop7pJmgii3kaahlkO3MMGryYp6oY7oISKSt64pX2BMFkqG3Ef9NvBE7BxoM'
      );
      setAlt('VOEZ app cover image');
      setGameplay(
        'Tap, swipe, and hold notes as they fall on colorful vertical lanes that appear, disappear, and move.'
      );
      setStrength1(
        'Visually stunning, with each level having its own colorful personality'
      );
      setStrength2(
        'Levels are unpredictable & fresh due to how the lanes change'
      );
      setStrength3('Great variety in music catering to many different tastes');
      setLinkname('Official Teaser');
      setLink('https://youtu.be/Bh6gQyJHbxI?si=Co4OwiYO-8pUXKA9');
    } else if (a1 == true && a2 == false) {
      setTitle('Deemo');
      setRd('November 2013');
      setDiff('Easy');
      setMusic('Classical (Piano)');
      setSrc(
        'https://play-lh.googleusercontent.com/_As2vGjTdYMHQHy2OZ8J3npK0uqkw2aKBTcHUI5UvqXsuMO2cQHEsjzFfbYZeOf6HA'
      );
      setAlt('Deemo app cover image');
      setGameplay(
        'Conventional; tap notes as they fall on a still horizontal line. Notably sensitive to inputs. Rewards high precision.'
      );
      setStrength1('Easy to learn, hard to master');
      setStrength2('Composition-accurate piano sound effects add to immersion');
      setStrength3('Well regarded story that blends well with the gameplay');
      setLinkname('Official Update Trailer');
      setLink('https://youtu.be/wAaT3CYl-a8?si=No7_9ayTO2HoQxGu');
    } else if (a1 == false && a2 == true) {
      setTitle('Dynamix');
      setRd('October 2014');
      setDiff('Hard');
      setMusic('Electronic');
      setSrc(
        'https://play-lh.googleusercontent.com/PmlNgEnpqpEQYHoDUfc_L-HDrxYnHCi1_Pg6X-GqMZaTPqvQVoijCmfxWDSl5fdoFdE'
      );
      setAlt('Dynamix app cover image');
      setGameplay(
        'Tap, hold, and slide notes as they fall on lines on the bottom, left, and right of the screen.'
      );
      setStrength1(
        'Extremely difficult gameplay that truly rewards practice & skill'
      );
      setStrength2(
        'Entirely gameplay-oriented, for those seeking a straightforward rhythm game'
      );
      setStrength3('Many songs by smaller artists not found in other games');
      setLinkname('Unofficial Gameplay Footage');
      setLink('https://youtu.be/bce1dInAJ8w?si=HOBfxyIBfiBIc0X5');
    } else if (a1 == false && a2 == false) {
      setTitle('Cytus');
      setRd('January 2012');
      setDiff('Medium');
      setMusic('Electronic');
      setSrc(
        'https://play-lh.googleusercontent.com/8CBpm7Ed1PMaRZlhAQTyQz82WAWXMv5k-Gy9ZTS6HK0j5hHU-slQR0EArIXQ7Wmb8w'
      );
      setAlt('Cytus app cover image');
      setGameplay(
        'A horizontal line moves up and down the screen, and notes must be pressed as they contact the line.'
      );
      setStrength1(
        'One-of-a-kind gameplay requiring constant, flexible movement'
      );
      setStrength2('Many intense levels available for challenge-seekers');
      setStrength3('Song collections with unusual, memorable subgenres');
      setLinkname('Official Update Trailer');
      setLink('https://youtu.be/n1CbxvguQ1g?si=OlNaiNEGz9zo_U5w');
    }

    document.querySelector('#page3_q3').style.display = 'none';
    document.querySelector('#page3_results').style.display = 'flex';
  }

  function handleClickReset() {
    document.querySelector('#page3_results').style.display = 'none';
    document.querySelector('#page3_initial').style.display = 'block';
  }

  return (
    <div id="page3">
      <div id="page3_recommendation_algo">
        <div id="page3_initial">
          <button type="submit" id="rec_button" onClick={handleClickStart}>
            Find the Perfect Rhythm Game for You
          </button>
        </div>
        <div id="page3_q1" className="page3_question">
          <p>What kind of difficulty would you prefer?</p>
          <div className="page3_choices">
            <button
              type="submit"
              className="choice_button"
              onClick={handleClickQ1A1}
            >
              Easy to pick up
            </button>
            <button
              type="submit"
              className="choice_button"
              onClick={handleClickQ1A2}
            >
              Complex & Challenging
            </button>
          </div>
        </div>
        <div id="page3_q2" className="page3_question">
          <p>What kind of content do you want in your game?</p>
          <div className="page3_choices">
            <button
              type="submit"
              className="choice_button"
              onClick={handleClickQ2A1}
            >
              Just the rhythm game parts
            </button>
            <button
              type="submit"
              className="choice_button"
              onClick={handleClickQ2A2}
            >
              A fleshed out story as well
            </button>
          </div>
        </div>
        <div id="page3_q3" className="page3_question">
          <p>
            Do you prefer a more modern game? (Note: Newer games may require
            newer hardware to run smoothly.)
          </p>
          <div className="page3_choices">
            <button
              type="submit"
              className="choice_button"
              onClick={handleClickQ3A1}
            >
              A newer game sounds great
            </button>
            <button
              type="submit"
              className="choice_button"
              onClick={handleClickQ3A2}
            >
              I don't mind an older game
            </button>
          </div>
        </div>
      </div>

      <div id="page3_results">
        <h3>Here's Your Match!</h3>
        <GameCard
          title={title}
          rd={rd}
          diff={diff}
          music={music}
          src={src}
          alt={alt}
          gameplay={gameplay}
          strength1={strength1}
          strength2={strength2}
          strength3={strength3}
          link_name={linkname}
          link={link}
        />
        <div id="page3_results_button">
          <button
            type="submit"
            id="page3_reset_button"
            onClick={handleClickReset}
          >
            Start Over
          </button>
        </div>
      </div>
    </div>
  );
}
