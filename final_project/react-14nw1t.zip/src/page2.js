import React from 'react';
import GameCard from './gamecard.js';

export default function Page2() {
  function handleClick() {
    document.querySelector('.page2_games_row_hidden_1').style.display = 'flex';
    document.querySelector('.page2_games_row_hidden_2').style.display = 'flex';
    document.querySelector('#page2_games_end').style.display = 'none';
  }

  return (
    <div id="page2">
      <p id="page2_p1">
        Here are just some of the mobile rhythm games I’ve played, and some
        basic details about them!
      </p>
      <div id="page2_p2_div">
        <p id="page2_p2">
          <strong>Additional Details: </strong>
        </p>
        <ul id="page2_p2_ul">
          <li>
            Difficulty: My thoughts on how difficult it is to learn the game’s
            basic mechanics
          </li>
          <li>Music: The main genre(s) of music featured in the game</li>
          <li>
            Gameplay: The core rhythm game mechanics of the game that make it
            special
          </li>
          <li>
            Strengths: The game’s three greatest strong points in my view (music
            selection is never included, as most of these games have great
            collections of songs)
          </li>
        </ul>
      </div>
      <div id="page2_games">
        <div className="page2_games_row">
          <GameCard
            title="Arcaea"
            rd="March 2017"
            diff="Hard"
            music="Electronic"
            src="https://img.utdstc.com/icon/5b7/89c/5b789cf76ea01189cb71d1d464810766b3c9d5f70f2ae3ee5239d4f804b9152b:200"
            alt="Arcaea app cover image"
            gameplay="A revolutionary “3D” rhythm game: notes come down a single lane, but vary in both horizontal and vertical positions."
            strength1="Incredibly satisfying gameplay once basics are grasped"
            strength2="Especially rewarding in the long term for those seeking a real challenge"
            strength3="Simple, clean presentation in gameplay and UI"
            link_name="Official Trailer"
            link="https://youtu.be/ZcF9JQ44_sw?si=bbLYHt9kAoNHhLuQ"
          />
          <GameCard
            title="Cytus II"
            rd="January 2018"
            diff="Medium"
            music="Electronic"
            src="https://play-lh.googleusercontent.com/OWPLo_aeRocMDZH_V0VRa06XT642hwoUav3JjxXY3LCtb_qnWQuXjhZ1lKdT8Inz0yIL"
            alt="Cytus II app cover image"
            gameplay="A horizontal line moves up and down the screen, and notes must be pressed as they contact the line."
            strength1="One-of-a-kind gameplay requiring constant, flexible movement"
            strength2="Well received story mode"
            strength3="Exceptional art direction across the board"
            link_name="Official Trailer"
            link="https://youtu.be/IAS52XC2pto?si=xB7fzchtjGidRaBy"
          />
        </div>
        <div className="page2_games_row">
          <GameCard
            title="Deemo"
            rd="November 2013"
            diff="Easy"
            music="Classical (Piano)"
            src="https://play-lh.googleusercontent.com/_As2vGjTdYMHQHy2OZ8J3npK0uqkw2aKBTcHUI5UvqXsuMO2cQHEsjzFfbYZeOf6HA"
            alt="Deemo app cover image"
            gameplay="Conventional; tap notes as they fall on a still horizontal line. Notably sensitive to inputs. Rewards high precision."
            strength1="Easy to learn, hard to master"
            strength2="Composition-accurate piano sound effects add to immersion"
            strength3="Well regarded story that blends well with the gameplay"
            link_name="Official Update Trailer"
            link="https://youtu.be/wAaT3CYl-a8?si=No7_9ayTO2HoQxGu"
          />
          <GameCard
            title="Muse Dash"
            rd="June 2018"
            diff="Easy"
            music="Electronic"
            src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQqBKUxYz0qLMyHq7Hti3ol1-KnwzIXg7bHmg&usqp=CAU"
            alt="Muse Dash app cover image"
            gameplay="Tap notes or dodge obstacles as they reach the goal point at the end of two horizontal lanes."
            strength1="Easy & fun to pick up and play any time"
            strength2="Bright colors & pop aesthetic may be particularly appealing to some"
            strength3="Frequent song updates"
            link_name="Nintendo Switch Version Trailer"
            link="https://youtu.be/1pt4kwFOpAg?si=g_nc21ChpOezURmM"
          />
        </div>
        <div className="page2_games_row_hidden_1">
          <GameCard
            title="VOEZ"
            rd="May 2016"
            diff="Medium"
            music="Variety"
            src="https://play-lh.googleusercontent.com/cS3tC7peop7pJmgii3kaahlkO3MMGryYp6oY7oISKSt64pX2BMFkqG3Ef9NvBE7BxoM"
            alt="VOEZ app cover image"
            gameplay="Tap, swipe, and hold notes as they fall on colorful vertical lanes that appear, disappear, and move."
            strength1="Visually stunning, with each level having its own colorful personality"
            strength2="Levels are unpredictable & fresh due to how the lanes change"
            strength3="Great variety in music catering to many different tastes"
            link_name="Official Teaser"
            link="https://youtu.be/Bh6gQyJHbxI?si=Co4OwiYO-8pUXKA9"
          />
          <GameCard
            title="Cytus"
            rd="January 2012"
            diff="Medium"
            music="Electronic"
            src="https://play-lh.googleusercontent.com/8CBpm7Ed1PMaRZlhAQTyQz82WAWXMv5k-Gy9ZTS6HK0j5hHU-slQR0EArIXQ7Wmb8w"
            alt="Cytus app cover image"
            gameplay="A horizontal line moves up and down the screen, and notes must be pressed as they contact the line."
            strength1="One-of-a-kind gameplay requiring constant, flexible movement"
            strength2="Many intense levels available for challenge-seekers"
            strength3="Song collections with unusual, memorable subgenres"
            link_name="Official Update Trailer"
            link="https://youtu.be/n1CbxvguQ1g?si=OlNaiNEGz9zo_U5w"
          />
        </div>
        <div className="page2_games_row_hidden_2">
          <GameCard
            title="Deemo II"
            rd="January 2022"
            diff="Easy"
            music="Classical (Piano)"
            src="https://play-lh.googleusercontent.com/H_zK8nYN2dEai8dh8Gd66eXMGkdOUOdp63Gxuldw9jlrg-tfYefHxDNBG9fjRkGxhA"
            alt="Deemo II app cover image"
            gameplay="Conventional; tap notes as they fall on a still horizontal line. Notably sensitive to inputs. Rewards high precision."
            strength1="Easy to learn, hard to master"
            strength2="Composition-accurate piano sound effects add to immersion"
            strength3="Heavy focus on narrative & non-rhythm-game gameplay"
            link_name="Official Release Trailer"
            link="https://youtu.be/hJooJyL8hI8?si=QmLDaUGu2skA4x7X"
          />
          <GameCard
            title="Dynamix"
            rd="October 2014"
            diff="Hard"
            music="Electronic"
            src="https://play-lh.googleusercontent.com/PmlNgEnpqpEQYHoDUfc_L-HDrxYnHCi1_Pg6X-GqMZaTPqvQVoijCmfxWDSl5fdoFdE"
            alt="Dynamix app cover image"
            gameplay="Tap, hold, and slide notes as they fall on lines on the bottom, left, and right of the screen."
            strength1="Extremely difficult gameplay that truly rewards practice & skill"
            strength2="Entirely gameplay-oriented, for those seeking a straightforward rhythm game"
            strength3="Many songs by smaller artists not found in other games"
            link_name="Unofficial Gameplay Footage"
            link="https://youtu.be/bce1dInAJ8w?si=HOBfxyIBfiBIc0X5"
          />
        </div>
        <div id="page2_games_end">
          <button type="submit" id="page2_games_seemore" onClick={handleClick}>
            See More
          </button>
        </div>
      </div>
    </div>
  );
}
