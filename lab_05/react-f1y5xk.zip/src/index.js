import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div id="main" className="divider">
      <h1>Terry Lee</h1>
      <h2>
        <a href="ttlee@usc.edu">ttlee@usc.edu</a>
      </h2>
      <h3 id="favColor">Favorite Color</h3>
      <h3>
        <a href="https://theta360.com/s/b1hqqemJTLK6yxMOHSwj0qi1M">
          Favorite Website
        </a>
      </h3>
      <h3>Favorite Activity (Below)</h3>
      <img
        src="https://media.istockphoto.com/id/457207765/photo/man-sitting-on-sofa-reading-book.jpg?s=612x612&w=0&k=20&c=TRZRBjFst18CckczwzuX1BEfqY3qIDVlfEQuhUq1kcM="
        alt="A man reading a book on his couch"
        id="activityImage"
      />
      <h3>List of Classes (Fall 2023)</h3>
      <ul id="list">
        <li>PSYC 372: Human Sexuality</li>
        <li>ITP 301: Front-End Web Development</li>
        <li>DSCI 351: Foundations of Data Management</li>
      </ul>
    </div>
  </React.StrictMode>
);
