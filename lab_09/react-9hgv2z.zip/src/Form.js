import React from 'react';
import { useState } from 'react';

export default function Form() {
  const [fullname, setFullname] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [comments, setComments] = useState('');
  const [tnc, setTnc] = useState(false);

  function handleOnChange(e) {
    if (e.target.name == 'fullname') {
      setFullname(e.target.value);
    } else if (e.target.name == 'password') {
      setPassword(e.target.value);
    } else if (e.target.name == 'confirm') {
      setConfirm(e.target.value);
    } else if (e.target.name == 'email') {
      setEmail(e.target.value);
    } else if (e.target.name == 'phone') {
      setPhone(e.target.value);
    } else if (e.target.name == 'comments') {
      setComments(e.target.value);
    } else if (e.target.name == 'tnc') {
      setTnc(!tnc);
    }
  }

  function handleOnSubmit(e) {
    var error = false;

    var fullNameError = '';
    var passwordError = '';
    var confirmError = '';
    var epError = '';
    var commentsError = '';
    var tncError = '';

    if (fullname == '') {
      error = true;
      fullNameError = 'Name cannot be empty.\n';
      console.log('Hello');
    } else if (fullname.indexOf(' ') == -1) {
      error = true;
      fullNameError = 'You must provide a full name.\n';
    } else {
      fullNameError = '';
    }

    if (password == '') {
      error = true;
      passwordError = 'Password cannot be empty\n';
    } else if (password.length < 5) {
      error = true;
      passwordError = 'Password must contain at least 5 characters.\n';
    } else if (
      password == password.toLowerCase() ||
      password == password.toUpperCase()
    ) {
      error = true;
      passwordError =
        'Password must contain uppercase and lowercase characters.\n';
    } else {
      passwordError = '';
    }

    if (confirm != password) {
      error = true;
      confirmError = 'Passwords do not match.\n';
    } else {
      confirmError = '';
    }

    if (email == '' && phone == '') {
      error = true;
      epError = 'You must provide either email or phone.\n';
    } else {
      epError = '';
    }

    if (comments.length > 100) {
      error = true;
      commentsError = 'Comments cannot exceed 100 characters.\n';
    } else {
      commentsError = '';
    }

    if (tnc == false) {
      error = true;
      tncError = 'You must accept Terms & Conditions.';
    } else {
      tncError = '';
    }

    if (error) {
      e.preventDefault();
      alert(
        fullNameError +
          passwordError +
          confirmError +
          epError +
          commentsError +
          tncError
      );
    } else {
      alert('Registration Successful');
    }
  }

  return (
    <div className="container my-3">
      <div className="row">
        <div className="col-12">
          <form onSubmit={handleOnSubmit}>
            <div className="my-3 row">
              <label htmlFor="full-name" className="col-sm-2 col-form-label">
                Full Name: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Tommy Trojan"
                  id="full-name"
                  name="fullname"
                  onChange={handleOnChange}
                  value={fullname}
                />
              </div>
            </div>

            <div className="my-3 row">
              <label htmlFor="password" className="col-sm-2 col-form-label">
                Password: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="password"
                  className="form-control"
                  id="password"
                  name="password"
                  onChange={handleOnChange}
                  value={password}
                />
              </div>
            </div>

            <div className="my-3 row">
              <label
                htmlFor="password-confirm"
                className="col-sm-2 col-form-label"
              >
                Confirm Password: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="password"
                  className="form-control"
                  id="password-confirm"
                  name="confirm"
                  onChange={handleOnChange}
                  value={confirm}
                />
              </div>
            </div>

            <div className="my-3 row">
              <label className="col-sm-2 col-form-label">
                Provide One: <span className="text-danger">*</span>
              </label>
              <div className="col-10">
                <div className="row">
                  <label htmlFor="email" className="col-sm-2 col-form-label">
                    Email:
                  </label>
                  <div className="col-sm-10">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="ttrojan@usc.edu"
                      id="email"
                      name="email"
                      onChange={handleOnChange}
                      value={email}
                    />
                  </div>

                  <label
                    htmlFor="phone"
                    className="mt-sm-2 col-sm-2 col-form-label"
                  >
                    Phone:
                  </label>
                  <div className="mt-sm-2 col-sm-10">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="(123) 456-7890"
                      id="phone"
                      name="phone"
                      onChange={handleOnChange}
                      value={phone}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="my-3 row">
              <label htmlFor="comment" className="col-sm-2 col-form-label">
                Comments:
              </label>
              <div className="col-sm-10">
                <textarea
                  className="form-control"
                  id="comment"
                  name="comments"
                  onChange={handleOnChange}
                  value={comments}
                ></textarea>

                <small id="comment-count" className="form-text text-right">
                  {comments.length} / 100
                </small>
              </div>
            </div>

            <div className="my-3 row">
              <label className="col-sm-2 col-form-label"></label>
              <div className="col-sm-10">
                <div className="form-check form-check-inline">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    id="terms"
                    name="tnc"
                    onChange={handleOnChange}
                    value={tnc}
                  />
                  <label className="form-check-label" htmlFor="terms">
                    I accept Terms & Conditions.
                    <span className="text-danger">*</span>
                  </label>
                </div>
              </div>
            </div>

            <div className="my-3 row">
              <div className="col-sm-10">
                <button type="submit" className="btn btn-primary">
                  Register
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
