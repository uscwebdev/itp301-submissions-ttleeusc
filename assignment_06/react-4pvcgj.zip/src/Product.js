import React from 'react';

export default function Product(props) {
  return (
    <div className="product">
      <div className="productNameDiv">
        <h2 className="productName">{props.name}</h2>
      </div>
      <img className="productImage" src={props.img} alt={props.imgalt} />
      <h3 className="productPrice">${props.price}</h3>
    </div>
  );
}
