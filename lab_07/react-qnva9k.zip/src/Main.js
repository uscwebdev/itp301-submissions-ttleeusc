import React from 'react';
import { useState } from 'react';

export default function Main() {
  const [src, setSrc] = useState(
    'https://www.sanrio.com/cdn/shop/articles/01132022_soc_pinterestboardcoverupdate_CN_1200x1200_10255920-d001-4530-a20e-3748a1ee61d8_1200x.png?v=1646098286'
  );
  const [alt, setAlt] = useState(
    'Cinnamoroll, a white dog with blue eyes, long ears, and a curly tail'
  );
  const [caption, setCaption] = useState('Cinnamoroll');

  function changeImage(newSrc, newAlt, newCaption) {
    setSrc(newSrc);
    setAlt(newAlt);
    setCaption(newCaption);
  }

  return (
    <div id="all">
      <h1>Sanrio Characters</h1>
      <div id="buttons">
        <button
          type="submit"
          class="imgBtn"
          id="imgBtn1"
          onClick={() => {
            changeImage(
              'https://www.sanrio.com/cdn/shop/articles/01132022_soc_pinterestboardcoverupdate_CN_1200x1200_10255920-d001-4530-a20e-3748a1ee61d8_1200x.png?v=1646098286',
              'Cinnamoroll, a white dog with blue eyes, long ears, and a curly tail',
              'Cinnamoroll'
            );
          }}
        >
          Image 1
        </button>
        <button
          type="submit"
          class="imgBtn"
          id="imgBtn2"
          onClick={() => {
            changeImage(
              'https://i.pinimg.com/736x/4d/72/c1/4d72c1de0c0ad345a5ff7efad12d90b5.jpg',
              'Corocorokuririn, a yellow hamster with a flower hat',
              'Corocorokuririn'
            );
          }}
        >
          Image 2
        </button>
        <button
          type="submit"
          class="imgBtn"
          id="imgBtn3"
          onClick={() => {
            changeImage(
              'https://6ixthsensela.com/cdn/shop/files/P4.jpg?v=1687394013&width=1100',
              'Pochacco, a white dog with black ears and no mouth',
              'Pochacco'
            );
          }}
        >
          Image 3
        </button>
        <button
          type="submit"
          class="imgBtn"
          id="imgBtn4"
          onClick={() => {
            changeImage(
              'https://i.shgcdn.com/babff9c2-14f7-45cc-99e5-49202494b0f4/-/format/auto/-/preview/3000x3000/-/quality/lighter/',
              'Badtz-Maru, a male penguin with spiky hair',
              'Badtz-Maru'
            );
          }}
        >
          Image 4
        </button>
        <button
          type="submit"
          class="imgBtn"
          id="imgBtn5"
          onClick={() => {
            changeImage(
              'https://www.sanrio.com/cdn/shop/articles/01132022_soc_pinterestboardcoverupdate_CH_1200x1200_3a7aa79c-390e-4d19-8f54-57d0ae28716e_1200x.png?v=1651008951',
              'Chococat, a black cat with big black eyes and a brown nose',
              'Chococat'
            );
          }}
        >
          Image 5
        </button>
      </div>
      <div id="mainImgArea">
        <img src={src} alt={alt} id="mainImg" />
      </div>
      <div id="captionArea">
        <p id="caption">{caption}</p>
      </div>
    </div>
  );
}
