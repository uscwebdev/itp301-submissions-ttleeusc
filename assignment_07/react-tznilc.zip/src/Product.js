import React from 'react';
import { useState } from 'react';

export default function Product(props) {
  const [counter, setCounter] = useState(0);

  function counterSubtract() {
    if (counter > 0) {
      setCounter(counter - 1);
    }
  }

  function counterAdd() {
    setCounter(counter + 1);
  }

  return (
    <div className="product">
      <div className="productNameDiv">
        <h2 className="productName">{props.name}</h2>
      </div>
      <img className="productImage" src={props.img} alt={props.imgalt} />
      <h3 className="productPrice">${props.price}</h3>
      <div className="productCounter">
        <button
          type="submit"
          className="minusButton"
          onClick={() => {
            counterSubtract();
          }}
        >
          -
        </button>
        <p className="counter">{counter}</p>
        <button
          type="submit"
          className="addButton"
          onClick={() => {
            counterAdd();
          }}
        >
          +
        </button>
      </div>
    </div>
  );
}
