import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import Product from './Product.js';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div id="all">
      <div id="header">
        <h1>Shopping Cart</h1>
      </div>
      <div id="body">
        <Product
          img="https://store.colorfulpalette.jp/cdn/shop/products/cap_220209_02_sp_1800x1800.jpg?v=1644345299"
          imgalt="Black baseball cap with pink text reading Shooting Star embroidered on the front"
          name="Shooting Star Baseball Cap"
          price="30"
        />
        <Product
          img="https://store.colorfulpalette.jp/cdn/shop/products/rakko_web_photo01-L_1800x1800.jpg?v=1642578149"
          imgalt="Sky blue t-shirt with a cartoon sea otter design"
          name="Sea Otter T-Shirt (L)"
          price="25"
        />
        <Product
          img="https://store.colorfulpalette.jp/cdn/shop/products/usagi_02_img_1800x1800.jpg?v=1672940707"
          imgalt="A purple bunny doll with pink ribbons on its right ear and neck"
          name="Purple Bunny Doll"
          price="15"
        />
        <Product
          img="https://store.colorfulpalette.jp/cdn/shop/products/1C_01-front-L_1800x1800.jpg?v=1668493249"
          imgalt="Black t-shirt with a skeleton design and purple splatter marks"
          name="Skeleton T-Shirt (L)"
          price="20"
        />
      </div>
      <div id="footer">
        <h4>Page by Terry Lee</h4>
      </div>
    </div>
  </React.StrictMode>
);
