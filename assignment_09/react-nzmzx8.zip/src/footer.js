import React from 'react';

export default function Footer() {
  return (
    <div id="footer">
      <hr id="footer_border" />
      <div id="footer_flex">
        <h5 id="footer_l">Website by Terry Lee</h5>
        <h5 id="footer_r">Last Updated: 11/20/2023</h5>
      </div>
    </div>
  );
}
