import React from 'react';
import GameCard from './gamecard.js';

export default function Page2() {
  return (
    <div id="page2">
      <h2 id="page2_h2">Mobile Rhythm Games: My Picks</h2>
      <p className="page2_p">
        Here are just some of the mobile rhythm games I’ve played, and some
        basic details about them!
      </p>
      <p className="page2_p">
        (Note: Difficulty describes my personal thoughts on how difficult it is
        to master the game’s basic mechanics. Music describes the main genre(s)
        of music featured in the game.)
      </p>
      <div id="page2_games">
        <div className="page2_games_row_1">
          <GameCard
            title="Arcaea"
            rd="March 2017"
            diff="Hard"
            music="Electronic"
            src="https://img.utdstc.com/icon/5b7/89c/5b789cf76ea01189cb71d1d464810766b3c9d5f70f2ae3ee5239d4f804b9152b:200"
            alt="Arcaea app cover image"
            description="Arcaea revolutionizes the usual rhythm game gameplay of notes coming down a single lane by also implementing a vertical axis; basically, not only do you have to press the notes along a horizontal line, you also have to keep track of their “height” as well. This makes the game extremely challenging, and fully grasping this 3D-gameplay may take quite a while. However, once you’ve mastered this core concept, Arcaea offers a wonderful variety of songs along with many challenging levels. The presentation of Arcaea is fantastic too, and the game also has a decently-regarded story mode that some may enjoy."
          />
          <GameCard
            title="Cytus II"
            rd="January 2018"
            diff="Medium"
            music="Electronic"
            src="https://play-lh.googleusercontent.com/OWPLo_aeRocMDZH_V0VRa06XT642hwoUav3JjxXY3LCtb_qnWQuXjhZ1lKdT8Inz0yIL"
            alt="Cytus II app cover image"
            description="Cytus II stands out among other rhythm games for its unique gameplay, in which you have to follow a horizontal line as it continuously moves up and down the screen, tapping notes as they contact the line. This unusual mechanic may make Cytus II intimidating, but it’s actually not too hard to learn! Once you understand the basics of Cytus II, the game really opens up, with the constant motion required by each level creating a special experience. Alongside this unique gameplay, Cytus II is also praised for its stellar visual presentation and its story mode. If you’re interested in a different type of rhythm game, Cytus II is a great place to start, for rhythm game beginners and veterans alike."
          />
        </div>
        <div className="page2_games_row_2">
          <GameCard
            title="Deemo"
            rd="November 2013"
            diff="Easy"
            music="Classical (Piano)"
            src="https://play-lh.googleusercontent.com/_As2vGjTdYMHQHy2OZ8J3npK0uqkw2aKBTcHUI5UvqXsuMO2cQHEsjzFfbYZeOf6HA"
            alt="Deemo app cover image"
            description="One of the older games on this list, Deemo is a simple game: all you have to do is tap notes as they touch a line at the bottom of the screen. This makes Deemo very easy to pick up, though as the game progresses, the high degree of precision required makes it one of the hardest games around to truly master. Still, Deemo is easy to enjoy for everyone, with its beautiful piano songs and composition-accurate piano sound effects making you really feel you’re playing the piano. The game also has a simple yet heartfelt story you progress through naturally as you play, another part of the game that makes it so memorable for fans even today."
          />
          <GameCard
            title="Muse Dash"
            rd="June 2018"
            diff="Easy"
            music="Electronic"
            src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQqBKUxYz0qLMyHq7Hti3ol1-KnwzIXg7bHmg&usqp=CAU"
            alt="Muse Dash app cover image"
            description="Muse Dash’s gameplay is quite basic, with notes only coming down two lanes. This means that at most, you only have to tap two points on the screen, though the higher-difficulty levels can still be quite hard due to the sheer speed at which you have to tap. Visually, Muse Dash is very colorful due to its bright colors and pop aesthetic, though the overwhelming effects in gameplay can become part of the game’s difficulty in certain levels. Alongside the simple gameplay, Muse Dash also receives frequent song updates, making it a game that’s easy to return to and play."
          />
        </div>
        <div id="page2_games_end">
          <button type="submit" id="page2_games_seemore">
            See More
          </button>
        </div>
      </div>
    </div>
  );
}
