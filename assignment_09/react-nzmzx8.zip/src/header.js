import React from 'react';

export default function Header() {
  return (
    <div id="header">
      <div id="header_flex">
        <h1 id="header_h1">The World of Mobile Rhythm Games</h1>
        <hr id="header_hr" />
        <button type="submit" className="header_button">
          Recommend Me a Game!
        </button>
      </div>
      <hr id="header_border" />
    </div>
  );
}
