import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import Header from './header.js';
import Page1 from './page1.js';
import Page2 from './page2.js';
import Page3 from './page3.js';
import Footer from './footer.js';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div id="all">
      <div id="header">
        <Header />
      </div>
      <div id="body">
        <Page1 />
        <hr className="body_divider" />
        <Page2 />
        <hr className="body_divider" />
        <Page3 />
      </div>
      <Footer />
    </div>
  </React.StrictMode>
);
