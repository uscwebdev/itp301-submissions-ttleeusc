import React from 'react';

export default function GameCard(prop) {
  return (
    <div className="gamecard">
      <div className="gamecard_top">
        <div className="gamecard_top_left">
          <h1 className="gamecard_title">{prop.title}</h1>
          <div className="gamecard_details">
            <p className="gamecard_rd">Released: {prop.rd}</p>
            <p className="gamecard_diff">Difficulty: {prop.diff}</p>
            <p className="gamecard_music">Music: {prop.music}</p>
          </div>
        </div>
        <div className="gamecard_top_right">
          <img className="gamecard_img" src={prop.src} alt={prop.alt} />
        </div>
      </div>
      <hr className="gamecard_hr" />
      <div className="gamecard_bottom">
        <p className="gamecard_description">{prop.description}</p>
      </div>
    </div>
  );
}
