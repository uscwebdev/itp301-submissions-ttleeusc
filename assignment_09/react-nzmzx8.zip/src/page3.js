import React from 'react';

export default function Page3() {
  return (
    <div id="page3">
      <h2 id="page3_h2">Rhythm Game Recommendation Algorithm</h2>
      <div id="page3_rec_buttons">
        <div className="page3_rec_buttons_sub">
          <button type="submit" className="rec_button">
            Recommend By Gameplay
          </button>
          <p>
            Filter by the type of gameplay you want in your ideal rhythm game.
            Great for beginners.
          </p>
        </div>
        <div id="page3_verticalhr"></div>
        <div className="page3_rec_buttons_sub">
          <button type="submit" className="rec_button">
            Recommend By Music
          </button>
          <p>
            Search for a song you like through an API, then find a game fitting
            that song's genre.
          </p>
        </div>
      </div>
    </div>
  );
}
