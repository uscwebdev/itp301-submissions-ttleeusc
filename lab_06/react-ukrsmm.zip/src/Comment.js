import React from 'react';

export default function Comment(props) {
  return (
    <div className="comment">
      <div className="commentTop">
        <img src={props.pfp} alt={props.pfpalt} />
        <div className="commentNameDate">
          <h1>{props.name}</h1>
          <h2>{props.date}</h2>
        </div>
      </div>
      <div className="commentBody">
        <p>{props.body}</p>
      </div>
    </div>
  );
}
