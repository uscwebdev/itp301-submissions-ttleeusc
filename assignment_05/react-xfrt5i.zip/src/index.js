import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div id="all">
      <h1 id="title">Thinking about MapleStory</h1>
      <h2></h2>
      <p>
        I first played{' '}
        <a href="https://en.wikipedia.org/wiki/MapleStory">MapleStory</a>, an
        MMO RPG, when I was around 10. Back then, I was in elementary school in
        Korea, and MapleStory was pretty popular among kids my age. I still
        remember begging my parents to help me make an account, then eventually
        seeing my older sister dragged into the whole ordeal since my parents
        weren't great with making video game accounts (to no surprise, in
        hindsight).
      </p>
      <img
        id="image1"
        src="https://images.ctfassets.net/5p1u9t4r48s4/58ZM0MS9HOY2DaAN63IlA0/3c9d7c3dc39150dfb0c1e346fe069409/Dirt_Cover_Photo.png"
        alt="placeholder"
      />
      <p>
        MapleStory is above all else, a very cute game. The game has a colorful,
        cartoon aesthetic that looks both adorable and beautiful. From the
        detailed background art to the charming monster designs to the unique
        NPC (non-playable characters) sprites, everything about the game's
        visuals made me fall in love with the pseudo-fantasy world. On top of
        the visuals, the game's music is simply perfect. Composed in a wide
        variety of styles from electronic to orchestral to folk instrumentals,
        the music was always catchy and added an extra layer of memorability to
        the different places you explored. In all honesty, the gameplay of
        MapleStory wasn't particularly great, being fairly repetitive like many
        other MMO RPGs. The story wasn't anything incredible either, being
        fairly simple and straightforward, though this wasn't a big deal for me
        as a kid. Still, with the world itself being so wonderfully presented,
        MapleStory ended up being a huge part of my childhood.
      </p>
      <img
        id="image2"
        src="https://i.ytimg.com/vi/saXRYiTgBx4/maxresdefault.jpg"
        alt="placeholder"
      />
      <p>
        In fact, I still think of MapleStory quite often. The game's soundtrack
        remains a staple of my playlist (for studying, working, or just
        relaxing), and I still keep up with news about the game. During the 2020
        quarantine, I ended up starting up a new account with my best friend,
        who was also nostalgic for the game. And though my more
        game-experienced, media literate adult self could now see just how dated
        and flawed MapleStory is (and was back then too), I found a lot of
        enjoyment exploring areas in the game, new and old. It wasn't just
        nostalgia hitting me, but a genuine appreciation of the game's art
        direction. Regardless of the game's quality as a whole, MapleStory is
        definitely one of the most important pieces of media to my life, and
        I'll always think of the game fondly, even over a decade after I first
        booted it up.
      </p>

      <hr />

      <div className="comment">
        <div className="commentTop">
          <img
            src="https://pbs.twimg.com/media/D8WBCPDU8AAH7iC.jpg:large"
            alt="placeholder"
          />
          <div className="commentNameDate">
            <h1>Orangestar</h1>
            <h2>09/21/2023</h2>
          </div>
        </div>
        <div className="commentBody">
          <p>The art direction in some of the new areas are really good too!</p>
        </div>
      </div>

      <div className="comment">
        <div className="commentTop">
          <img
            src="https://a.pinatafarm.com/312x296/ae7f8ccd22/sad-thumbs-up-cat.jpg"
            alt="placeholder"
          />
          <div className="commentNameDate">
            <h1>DECO*27</h1>
            <h2>09/21/2023</h2>
          </div>
        </div>
        <div className="commentBody">
          <p>Raindrop Flower is a 10/10 song... so much nostalgia...</p>
        </div>
      </div>

      <div className="comment">
        <div className="commentTop">
          <img
            src="https://s.pacn.ws/1/p/12e/project-sekai-colorful-stage-feat-hatsune-miku-nesoberi-plush-a-691289.6.jpg?v=rinpfe"
            alt="placeholder"
          />
          <div className="commentNameDate">
            <h1>tokotoko</h1>
            <h2>09/22/2023</h2>
          </div>
        </div>
        <div className="commentBody">
          <p>
            I never played the game but it's cool that so many people are
            nostalgic for it
          </p>
        </div>
      </div>

      <div className="comment">
        <div className="commentTop">
          <img
            src="https://i1.sndcdn.com/artworks-FPUQxi6GJ6SmvUMt-KzBEzQ-t500x500.jpg"
            alt="placeholder"
          />
          <div className="commentNameDate">
            <h1>Aqu3ra</h1>
            <h2>09/23/2023</h2>
          </div>
        </div>
        <div className="commentBody">
          <p>the game was definitely better in 2010 though</p>
        </div>
      </div>
    </div>
  </React.StrictMode>
);
